/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paninaro_nodb;

/**
 *
 * @author matte
 */
public class prodotto {

    String nome;
    double prezzo;
    int rimanenti;
    double tot_parziale=0;
    int pezzi_presi=0;

    public prodotto(String nome, double prezzo, int rimanenti) {
        this.nome = nome;
        this.prezzo = prezzo;
        this.rimanenti = rimanenti;
    }

    public String get_nome() {
        return this.nome;
    }

    public double get_prezzo() {
        return this.prezzo;
    }

    public int get_rimanenti() {
        return this.rimanenti;
    }
    
    public int get_pezzi_presi(){
        return this.pezzi_presi;
    }

    public void modify_rimanenti(boolean type) { //type=true funzione +; type=false funzione -
        if (type && this.rimanenti != 0) {
            this.rimanenti--;
            this.tot_parziale+=this.prezzo;
            this.pezzi_presi++;
        } else if (!type) {
            this.rimanenti++;
            this.tot_parziale-=this.prezzo;
            this.pezzi_presi--;
        } else {}
    }
    
//    public String get_ordine(){
//        return (this.nome+", "+this.pezzi_presi);
//    }

}
