/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Paninaro_2;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import static Paninaro_2.Database.getConnection;

/**
 *
 * @author matte
 */
public class prodotto {

    //tutti i riferimenti a rimanenti devono essere collegamenti diretti al db
    String nome;
    double prezzo;
    public int rimanenti;
    public int pezzi_presi = 0;

    public prodotto(String nome, double prezzo, int rimanenti) {
        this.nome = nome;
        this.prezzo = prezzo;
        this.rimanenti = rimanenti;
    }

    public String get_nome() {
        return this.nome;
    }

    public double get_prezzo() {
        return this.prezzo;
    }

    public int get_rimanenti() {
        return this.rimanenti;
    }

    public int get_pezzi_presi() {
        return this.pezzi_presi;
    }

    public void set_zero() {
        this.pezzi_presi = 0;
    }

    public double restituzione() throws Exception {
        this.rimanenti += this.pezzi_presi;
        double subtot = this.prezzo * (double) this.pezzi_presi;
        restituisci(this.pezzi_presi);
        this.pezzi_presi = 0;
        return subtot;
    }

    public void restituisci(int pezzi) throws Exception {
        Connection con;
        con = getConnection();
        Statement edit;
        edit = con.createStatement();
        String sql = "UPDATE `prodotti` SET `Quantità`=Quantità+" + Integer.toString(pezzi) + " WHERE ID ='" + gui.id + "'";
        edit.executeUpdate(sql);
        edit.close();
        con.close();
    }

    public void aggiungi() throws Exception {
        Connection con;
        con = getConnection();
        Statement edit;
        edit = con.createStatement();
        String sql = "UPDATE `prodotti` SET `Quantità`=Quantità-1 WHERE ID ='" + gui.id + "'";
        edit.executeUpdate(sql);
        sql = "UPDATE `ordini` SET `" + get_nome() + "`=`" + get_nome() + "`+1 WHERE classe =" + gui.aula;
        edit.executeUpdate(sql);
        edit.close();
        con.close();
    }

    public void rimuovi() throws Exception {
        Connection con;
        con = getConnection();
        Statement edit;
        edit = con.createStatement();
        String sql = "UPDATE `prodotti` SET `Quantità`=Quantità+1 WHERE ID ='" + gui.id + "'";
        edit.executeUpdate(sql);
        sql = "UPDATE `ordini` SET `" + get_nome() + "`=`" + get_nome() + "`-1 WHERE classe =" + gui.aula;
        edit.executeUpdate(sql);
        edit.close();
        con.close();
    }

    public void modify_rimanenti(boolean type) { //type=true funzione +; type=false funzione -
        if (type && this.rimanenti != 0) {
            try {
                this.aggiungi();
                this.rimanenti_db();
                this.rimanenti--;
                this.pezzi_presi++;
            } catch (Exception ex) {
                Logger.getLogger(prodotto.class.getName()).log(Level.SEVERE, null, ex);
            }

        } else if (!type) {
            try {
                this.rimuovi();
                this.rimanenti_db();
                this.rimanenti++;
                this.pezzi_presi--;
            } catch (Exception ex) {
                Logger.getLogger(prodotto.class.getName()).log(Level.SEVERE, null, ex);
            }
        } else {
        }
    }

    public void rimanenti_db() throws Exception {
        Connection con;
        con = getConnection();
        Statement stmt;
        stmt = con.createStatement();
        String SQL = "SELECT Quantità FROM prodotti WHERE ID='" + gui.id + "'";
        ResultSet rs;
        rs = stmt.executeQuery(SQL);
        rs.next();
        rimanenti = rs.getInt(1);
        rs.close();
        stmt.close();
        con.close();
    }

    public int pezzi_presi_db() throws Exception {
        Connection con;
        con = getConnection();
        Statement stmt;
        stmt = con.createStatement();
        String SQL = "SELECT `" + this.nome + "` FROM `ordini` WHERE `classe`='" + gui.aula + "'";
        ResultSet rs;
        rs = stmt.executeQuery(SQL);
        rs.next();
        pezzi_presi = rs.getInt(1);
        rs.close();
        stmt.close();
        con.close();
        return pezzi_presi;

    }

}
