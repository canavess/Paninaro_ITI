/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Paninaro_2;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author Ruben
 */
public class Database {

    public static int count;
    public static String username = "";
    public static String password = "";
    private static final String path = "C:\\Users\\matte\\Documents\\NetBeansProjects\\Paninaro_2.0_funzionante\\src\\Paninaro_2\\credenziali_database.txt";

    public static Connection getConnection() throws Exception {
        try {
            String driver = "com.mysql.jdbc.Driver";
            String url = "jdbc:mysql://localhost:3306/paninaro_itis";
//            String url = "jdbc:mysql://192.168.0.226:3306/paninaro_itis";

            Class.forName(driver);
            Connection conn = DriverManager.getConnection(url, Database.username, Database.password);
            return conn;
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println(e);
        }
        return null;
    }

    public static int numerorighe() throws Exception {
        Connection con;
        con = getConnection();
        Statement stmt;
        stmt = con.createStatement();
        String SQL = "SELECT count(*) FROM prodotti";
        ResultSet rs;
        rs = stmt.executeQuery(SQL);
        rs.next();
        int cont;
        cont = rs.getInt(1);
        rs.close();
        stmt.close();
        con.close();
        return cont;
    }

    public static void read_database() throws IOException {
        String text = "";
        text = gui.readLineByLineJava8(path);
        for (int k = 0; k < text.length(); k++) {
            if (text.charAt(k) == '=') {
                if (Database.username.isEmpty()) {
                    Database.username = text.substring(k + 1, text.indexOf('-', k));
                } else if (Database.password.isEmpty()) {
                    if (!text.substring(k + 1, text.length() - 1).equals("\"")) {
                        Database.password = text.substring(k + 2, text.length() - 2);
                    }
                }
            }
        }
    }

}
